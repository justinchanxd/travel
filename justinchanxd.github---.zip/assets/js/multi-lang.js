var arrLang = {
	'en':{
		'home':'Home',
		'places':'Places';
	}
	'ch':{
		'home':'主頁';
		'places':'地點'
	}
}

function 